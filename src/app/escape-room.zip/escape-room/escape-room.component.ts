import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { RouterModule } from '@angular/router';

// --- Interfaces and Enums ---
enum GameState { Introduction, FindNote, NoteFound, Quiz, QuizComplete }
interface Dialogue { character: string; text: string; }
interface HotspotConfig { x: number; y: number; width: number; height: number; }

// --- Asset Paths ---
const imagePaths = {
  base: '/assets/images/escape_room_raw_empty_final_people_zoomed_good_2.png',
  hrHover: '/assets/images/right_person_look.png',
  colleagueHover: '/assets/images/left_person_look.png',
  rightBoardZoomed: '/assets/images/right_board.png',
  leftBoardZoomed: '/assets/images/left_board.png',
  hrTalking: '/assets/images/right_person_talking.png',
  colleagueTalking: '/assets/images/left_person_talking.png',
  hrQuiz: '/assets/images/right_person_talking_simple.png',
  drawers: '/assets/images/drawers.png',
  drawers_opened: '/assets/images/drawers_opened.png',
  folders: '/assets/images/folders.png',
  folders_opened: '/assets/images/folders_opened.png',
  note: '/assets/images/note.png'
};

@Component({
  selector: 'app-escape-room',
  templateUrl: './escape-room.component.html',
  styleUrls: ['./escape-room.component.scss'],
  standalone: true,
  imports: [ CommonModule, MatCardModule, MatButtonModule, MatIconModule, RouterModule ],
  animations: [
    trigger('fadeInOut', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(20px)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateY(0)' })),
      ]),
      transition(':leave', [
        animate('300ms ease-in', style({ opacity: 0, transform: 'translateY(20px)' }))
      ]),
    ])
  ]
})
export class EscapeRoomComponent implements OnInit, OnDestroy {

  // Expose to template
  public GameState = GameState;
  public imagePaths = imagePaths;

  // RESTRUCTURED HOTSPOTS
  hotspots = {
    mainView: {
      hrManager:  { x: 65, y: 30, width: 25, height: 60 },
      colleague:  { x: 15, y: 45, width: 20, height: 50 },
      drawer:     { x: 78, y: 75, width: 18, height: 20 },
      dossiers:   { x: 5,  y: 68, width: 15, height: 15 },
      rightBoard: { x: 75, y: 5,  width: 22, height: 35 },
      leftBoard:  { x: 5,  y: 5,  width: 20, height: 30 },
    },
    rightBoardView: {
      noteOnBoard: { x: 10, y: 60, width: 15, height: 25 },
    },
    leftBoardView: {
      message: { x: 10, y: 10, width: 80, height: 80 },
    },
    drawersView: {
      open: { x: 25, y: 25, width: 50, height: 50 },
    },
    foldersView: {
      open: { x: 20, y: 20, width: 60, height: 60 },
    }
  };

  currentState: GameState = GameState.Introduction;
  currentBackgroundUrl: string = imagePaths.base;
  isRightBoardZoomed: boolean = false;
  isLeftBoardZoomed: boolean = false;
  isDrawersZoomed: boolean = false;
  isFoldersZoomed: boolean = false;
  isDrawerOpened: boolean = false;
  isFoldersOpened: boolean = false;
  isNoteVisible: boolean = false;
  isQuizWrong: boolean = false;
  showHints: boolean = false;
  isFullscreen: boolean = false;
  quizFeedback: string = '';
  quizPositionClass: string = 'center';
  activeDialogue: Dialogue | null = null;
  displayedDialogueText: string = '';
  isTyping: boolean = false;
  private dialogueInterval: any;
  zoomStyle: { [key: string]: string } = {};

  // New getter to simplify template logic
  public get isMainViewActive(): boolean {
    return !this.isRightBoardZoomed && !this.isLeftBoardZoomed && !this.isDrawersZoomed && !this.isFoldersZoomed;
  }

  constructor(@Inject(DOCUMENT) private document: Document) {}

  ngOnInit(): void {
    this.currentState = GameState.Introduction;
    this.document.addEventListener('fullscreenchange', this.onFullscreenChange);
  }

  ngOnDestroy(): void {
    if (this.dialogueInterval) clearInterval(this.dialogueInterval);
    this.document.removeEventListener('fullscreenchange', this.onFullscreenChange);
  }

  private playSound(soundFile: string): void { console.log(`Playing sound: ${soundFile}`); }

  private updateBackground(): void {
    if (this.currentState === GameState.Quiz) this.currentBackgroundUrl = imagePaths.hrQuiz;
    else if (this.isRightBoardZoomed) this.currentBackgroundUrl = imagePaths.rightBoardZoomed;
    else if (this.isLeftBoardZoomed) this.currentBackgroundUrl = imagePaths.leftBoardZoomed;
    else if (this.isDrawerOpened) this.currentBackgroundUrl = imagePaths.drawers_opened;
    else if (this.isDrawersZoomed) this.currentBackgroundUrl = imagePaths.drawers;
    else if (this.isFoldersOpened) this.currentBackgroundUrl = imagePaths.folders_opened;
    else if (this.isFoldersZoomed) this.currentBackgroundUrl = imagePaths.folders;
    else this.currentBackgroundUrl = imagePaths.base;
  }

  private applyZoom(hotspotKey: string, zoomLevel: number = 1.5): void {
    const hotspot = this.hotspots.mainView[hotspotKey as keyof typeof this.hotspots.mainView];
    if (!hotspot) return;
    const originX = hotspot.x + hotspot.width / 2;
    const originY = hotspot.y + hotspot.height / 2;
    this.zoomStyle = {
      'transform': `scale(${zoomLevel})`,
      'transform-origin': `${originX}% ${originY}%`,
    };
  }

  private resetZoom(): void {
    this.zoomStyle = {
      'transform': 'scale(1)',
      'transform-origin': 'center center',
    };
  }
  
  onCharacterHover(character: 'hrManager' | 'colleague'): void {
    if ((this.currentState !== GameState.Introduction && this.currentState !== GameState.FindNote) || !this.isMainViewActive || this.activeDialogue) return;
    this.currentBackgroundUrl = character === 'hrManager' ? imagePaths.hrHover : imagePaths.colleagueHover;
  }

  onCharacterLeave(): void {
    if (this.activeDialogue) return;
    this.updateBackground();
  }

  onCharacterClick(character: 'hrManager' | 'colleague'): void {
    if (this.isNoteVisible) return;
    this.playSound('character-click.mp3');
    this.applyZoom(character);

    let dialogueText = '';
    if (character === 'colleague') {
      this.currentBackgroundUrl = imagePaths.colleagueTalking;
      dialogueText = this.currentState >= GameState.NoteFound
        ? "Alma! You found the note, great. Let me know if you need help."
        : "Hey Alma, welcome! I'm just finishing up a report. Let me know if you need anything.";
      this.showDialogue({ character: 'Colleague', text: dialogueText });
    }

    if (character === 'hrManager') {
      this.currentBackgroundUrl = imagePaths.hrTalking;
      switch (this.currentState) {
        case GameState.Introduction:
          dialogueText = "Hi Alma! There are some things you should know regarding cultural awareness before starting to work here, because many colleagues come from different cultures.";
          break;
        case GameState.NoteFound:
          dialogueText = "Good! You are starting to understand cultural awareness. Please, answer the following question.";
          break;
        case GameState.FindNote:
           dialogueText = "Remember to find the sticky note on the board. It has important information.";
          break;
      }
      this.showDialogue({ character: 'HR Manager', text: dialogueText });
    }
  }

  postponeQuest(): void {
    this.dismissDialogue();
  }

  startQuest(): void {
    this.playSound('quest-start.mp3');
    this.currentState = GameState.FindNote;
    this.showDialogue({
      character: 'HR Manager',
      text: "In the room, there is a sticky note. Find it, read it carefully, and bring it to me."
    });
  }

  startQuiz(): void {
     this.playSound('quiz-start.mp3');
     this.dismissDialogue();
     this.currentState = GameState.Quiz;
     this.quizPositionClass = 'bottom-right'; 
     this.updateBackground();
  }

  onHotspotClick(hotspot: string): void {
    if (this.currentState !== GameState.FindNote || this.isNoteVisible) return;
    this.dismissDialogue();
    
    switch (hotspot) {
      // Main View Clicks
      case 'drawer':
        this.isDrawersZoomed = true;
        this.applyZoom('drawer', 2.0);
        this.updateBackground();
        this.showDialogue({ character: 'System', text: "A desk with drawers." });
        break;
      case 'dossiers':
        this.isFoldersZoomed = true;
        this.applyZoom('dossiers', 2.5);
        this.updateBackground();
        this.showDialogue({ character: 'System', text: "Some folders." });
        break;
      case 'rightBoard':
        this.isRightBoardZoomed = true;
        this.applyZoom('rightBoard', 1.8);
        this.updateBackground();
        break;
      case 'leftBoard':
        this.isLeftBoardZoomed = true;
        this.applyZoom('leftBoard', 1.8);
        this.updateBackground();
        break;
      
      // Zoomed View Clicks
      case 'zoomedDrawerClick':
        this.isDrawerOpened = true;
        this.updateBackground();
        this.showDialogue({ character: 'System', text: "Just some old files... Nothing of interest here." });
        break;
      case 'zoomedFoldersClick':
        this.isFoldersOpened = true;
        this.updateBackground();
        this.showDialogue({ character: 'System', text: "A lot of paperwork, but no sticky note here." });
        break;
      case 'zoomedLeftBoardMessage':
        this.showDialogue({ character: 'System', text: "This board is just for weekly announcements. No sticky note here." });
        break;
      case 'note':
        this.playSound('pickup-note.mp3');
        this.isNoteVisible = true;
        break;
    }
  }

  private showDialogue(dialogue: Dialogue): void {
    this.activeDialogue = dialogue;
    this.startTypewriter();
  }
  
  private startTypewriter(): void {
    if (!this.activeDialogue) return;
    if (this.dialogueInterval) clearInterval(this.dialogueInterval);

    this.isTyping = true;
    this.displayedDialogueText = '';
    const fullText = this.activeDialogue.text;
    let i = 0;

    this.dialogueInterval = setInterval(() => {
      if (i < fullText.length) {
        this.displayedDialogueText += fullText.charAt(i);
        i++;
      } else {
        clearInterval(this.dialogueInterval);
        this.isTyping = false;
      }
    }, 30);
  }
  
  onDialoguePanelClick(): void {
    if (this.isTyping) {
        this.skipTyping();
    }
  }

  private skipTyping(): void {
    if (!this.activeDialogue || !this.isTyping) return;
    clearInterval(this.dialogueInterval);
    this.displayedDialogueText = this.activeDialogue.text;
    this.isTyping = false;
    this.playSound('text-reveal.mp3');
  }

  dismissDialogue(): void {
    if (!this.activeDialogue) return;
    this.playSound('dialogue-close.mp3');
    const wasCharacterInteraction = this.activeDialogue.character !== 'System' && this.activeDialogue.character !== 'System Hint';
    this.activeDialogue = null;
    this.isTyping = false;
    if (this.dialogueInterval) clearInterval(this.dialogueInterval);
    
    if (wasCharacterInteraction) {
      this.resetZoom();
      this.updateBackground();
    }
  }

  requestHint(): void {
    if (this.showHints) return;
    this.playSound('hint-chime.mp3');
    this.showHints = true;
    let hintText = '';

    if (this.isRightBoardZoomed) {
        hintText = "You're looking at the right board. The note should be clearly visible somewhere on it.";
    } else if (this.isLeftBoardZoomed || this.isDrawersZoomed || this.isFoldersZoomed) {
        hintText = "This is an interesting spot, but the HR manager said the note was on a board.";
    } else {
        hintText = 'The HR manager mentioned a sticky note. A bulletin board seems like a good place to check.';
    }

    this.showDialogue({ character: 'System Hint', text: hintText });
    setTimeout(() => { this.showHints = false; }, 5000);
  }
  
  goBack(): void {
    this.playSound('zoom-out.mp3');
    this.dismissDialogue();

    if (this.isDrawerOpened) {
        this.isDrawerOpened = false;
    } else if (this.isFoldersOpened) {
        this.isFoldersOpened = false;
    } else if (this.isDrawersZoomed || this.isFoldersZoomed || this.isRightBoardZoomed || this.isLeftBoardZoomed) {
        this.isDrawersZoomed = false;
        this.isFoldersZoomed = false;
        this.isRightBoardZoomed = false;
        this.isLeftBoardZoomed = false;
        this.resetZoom();
    }
    this.updateBackground();
  }

  closeNote(): void {
    this.playSound('putdown-note.mp3');
    this.isNoteVisible = false;
    this.currentState = GameState.NoteFound;
    this.goBack(); // Resets zoom and background
    this.showDialogue({
        character: 'System',
        text: "I should show this to the HR Manager now."
    });
  }

  submitQuiz(answer: boolean): void {
     this.quizFeedback = '';
     this.isQuizWrong = false;
    if (answer) {
      this.playSound('success-chime.mp3');
      this.currentState = GameState.QuizComplete;
    } else {
      this.playSound('error-buzz.mp3');
      this.isQuizWrong = true;
      this.quizFeedback = "Think again… In one country, a thumb-up means ‘good job’ (Western countries), but in another (Middle Eastern countries), it can be seen as rude. Are gestures always universal?";
    }
  }

  toggleFullscreen(): void {
    if (!this.document.fullscreenElement) {
        this.document.documentElement.requestFullscreen();
    } else {
        this.document.exitFullscreen();
    }
  }

  private onFullscreenChange = (): void => {
    this.isFullscreen = !!this.document.fullscreenElement;
  }
}