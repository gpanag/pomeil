import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { RouterModule } from '@angular/router';

// --- Interfaces and Enums ---
enum GameState { Introduction, FindNote, NoteFound, Quiz, QuizComplete, FindPaper, PaperFound, PuzzleTwo, PuzzleThree, AllQuestsComplete }
interface Dialogue { character: string; text: string; }
interface QuizQuestion { type: string; text: string; answer: boolean; hint: string; }
interface HotspotConfig { x: number; y: number; width: number; height: number; }

// --- Asset Paths ---
const imagePaths = {
  base: '/assets/images/escape_room_raw_empty_final_people_zoomed_good_2.png',
  hrHover: '/assets/images/right_person_look.png',
  colleagueHover: '/assets/images/left_person_look.png',
  hrHover_door_open: '/assets/images/right_person_look_open_door.png',
  colleagueHover_door_open: '/assets/images/left_person_look_open_door.png',
  rightBoardZoomed: '/assets/images/right_board.png',
  leftBoardZoomed: '/assets/images/left_board.png',
  hrTalking: '/assets/images/right_person_talking.png',
  colleagueTalking: '/assets/images/left_person_talking.png',
  hrQuiz: '/assets/images/right_person_talking_simple.png',
  drawers: '/assets/images/drawers.png',
  drawers_opened: '/assets/images/drawers_opened.png',
  folders: '/assets/images/folders.png', // This is the 'desk_dossiers'
  folders_opened: '/assets/images/folders_opened.png', // This is the 'desk_dossiers' opened
  note: '/assets/images/note.png',
  base_door_open: '/assets/images/base_door_open.png',
  colleague_thumbs_up: '/assets/images/colleague_thumbs_up.png', 
  paper: '/assets/images/paper.jpg', 
  puzzleTwoBackground: '/assets/images/right_person_talking_simple.png',
  puzzleThreeBackground: '/assets/images/right_person_talking_simple.png',
};

@Component({
  selector: 'app-escape-room',
  templateUrl: './escape-room.component.html',
  styleUrls: ['./escape-room.component.scss'],
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule, MatIconModule, RouterModule],
  animations: [
    trigger('fadeInOut', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(20px)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateY(0)' })),
      ]),
      transition(':leave', [
        animate('300ms ease-in', style({ opacity: 0, transform: 'translateY(20px)' }))
      ]),
    ])
  ]
})
export class EscapeRoomComponent implements OnInit, OnDestroy {

  public GameState = GameState;
  public imagePaths = imagePaths;
  public isPreloading: boolean = true;

  hotspots = {
    mainView: {
      hrManager: { x: 75, y: 30, width: 10, height: 40 },
      colleague: { x: 25, y: 45, width: 15, height: 40 },
      // NOTE Quest 'drawer'
      drawer: { x: 60, y: 60, width: 15, height: 18 },
      // NOTE Quest 'desk' (dossiers)
      desk_dossiers: { x: 0, y: 58, width: 14, height: 16 }, 
      // PAPER Quest 'desk' (drawers)
      desk_drawers: { x: 58, y: 50, width: 16, height: 18 }, 
      
      rightBoard: { x: 55, y: 35, width: 13, height: 15 },
      leftBoard: { x: 33, y: 35, width: 13, height: 15 },
      laptop: { x: 14, y: 58, width: 10, height: 10 }, 
      exitDoor: { x: 46, y: 30, width: 10, height: 35 }, 
    },
    rightBoardView: { noteOnBoard: { x: 45, y: 63, width: 4, height: 8 } },
    leftBoardView: { message: { x: 12, y: 27, width: 38, height: 44 } },
    // NOTE Quest 'drawer' zoomed click
    drawersView: { open: { x: 76, y: 42, width: 17, height: 16 } },
    // NOTE Quest 'desk' (dossiers) zoomed click
    desk_dossiers_View: { open: { x: 5, y: 50, width: 30, height: 44 } },
    // PAPER Quest 'desk' (drawers) zoomed click
    desk_drawers_View: { open: { x: 40, y: 20, width: 50, height: 20 } }, 
  };

  puzzleThreeOptions: { [key: string]: string } = {
    'c': 'Listen attentively without interrupting', 
    'b': 'Avoid making jokes or comments about the accent', 
    'a': 'Ask politely for clarification if something is unclear', 
    'd': 'Show appreciation for their contribution' 
  };
  puzzleThreeSequence: string[] = [];
  puzzleThreeFeedback: string = '';

  currentState: GameState = GameState.Introduction;
  currentBackgroundUrl: string = imagePaths.base;
  isDoorOpen: boolean = false; 
  isRightBoardZoomed: boolean = false;
  isLeftBoardZoomed: boolean = false;
  
  // Refactored states
  isDrawersZoomed: boolean = false; // Note quest drawer
  isDrawerOpened: boolean = false;
  isDeskDossiersZoomed: boolean = false; // Note quest desk (dossiers)
  isDeskDossiersOpened: boolean = false;
  isDeskDrawersZoomed: boolean = false; // Paper quest desk (drawers)
  isDeskDrawersOpened: boolean = false;

  isNoteVisible: boolean = false;
  isPaperVisible: boolean = false; 
  isQuizWrong: boolean = false;
  showHints: boolean = false;
  isFullscreen: boolean = false;
  isQuizCompleteOverlayVisible: boolean = false;
  isGameCompleteOverlayVisible: boolean = false; 
  quizFeedback: string = '';
  quizPositionClass: string = 'center';
  activeDialogue: Dialogue | null = null;
  displayedDialogueText: string = '';
  isTyping: boolean = false;
  private dialogueInterval: any;
  zoomStyle: { [key: string]: string } = {
    'transform': 'scale(1)',
    'transform-origin': 'center center'
  };

  hasFoundNote: boolean = false;
  hasFoundPaper: boolean = false;
  hasLaptopHint: boolean = false; 
  hasShownQuizCompletePart2: boolean = false; 
  hasShownPaperFoundPart2: boolean = false; 
  hasShownGameCompletePart2: boolean = false; 

  quizTitle: string = '';
  quizQuestions: QuizQuestion[] = [];
  currentQuizQuestionIndex: number = 0;

  public get isMainViewActive(): boolean {
    return !this.isRightBoardZoomed && !this.isLeftBoardZoomed && !this.isDrawersZoomed && !this.isDeskDossiersZoomed && !this.isDeskDrawersZoomed; 
  }

  public get isQuizActive(): boolean {
    return this.currentState === GameState.Quiz ||
      this.currentState === GameState.PuzzleTwo ||
      this.currentState === GameState.PuzzleThree;
  }

  public get currentQuestion(): QuizQuestion | null {
    if (this.quizQuestions.length > this.currentQuizQuestionIndex) {
      return this.quizQuestions[this.currentQuizQuestionIndex];
    }
    return null;
  }

  constructor(@Inject(DOCUMENT) private document: Document) { }

  ngOnInit(): void {
    this.currentState = GameState.Introduction;
    this.document.addEventListener('fullscreenchange', this.onFullscreenChange);
    this.preloadImages();
  }

  private async preloadImages(): Promise<void> {
    this.isPreloading = true;
    const paths = Object.values(imagePaths);
    const promises = paths.map(path => {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = resolve;
        img.onerror = reject;
        img.src = path;
      });
    });
    try {
      await Promise.all(promises);
      console.log('All images preloaded successfully.');
    } catch (error) {
      console.error('Failed to preload one or more images:', error);
    }
    this.isPreloading = false;
  }

  ngOnDestroy(): void {
    if (this.dialogueInterval) clearInterval(this.dialogueInterval);
    this.document.removeEventListener('fullscreenchange', this.onFullscreenChange);
  }

  private playSound(soundFile: string): void {
    const audio = new Audio();
    audio.src = `/assets/audio/${soundFile}`;
    audio.load();
    audio.play()
      .catch(error => console.error(`Error playing sound ${soundFile}:`, error));
    console.log(`Attempting to play sound: ${audio.src}`);
  }

  private updateBackground(): void {

    if (this.currentState === GameState.AllQuestsComplete) {
      this.currentBackgroundUrl = imagePaths.base_door_open;
      return; 
    }

    if (this.currentState === GameState.Quiz || this.currentState === GameState.PuzzleTwo || this.currentState === GameState.PuzzleThree) {
      this.currentBackgroundUrl = imagePaths.hrQuiz;
    }
    else if (this.isRightBoardZoomed) { this.currentBackgroundUrl = imagePaths.rightBoardZoomed; }
    else if (this.isLeftBoardZoomed) { this.currentBackgroundUrl = imagePaths.leftBoardZoomed; }
    
    // Note Quest Drawer
    else if (this.isDrawersZoomed) { 
      this.currentBackgroundUrl = this.isDrawerOpened ? imagePaths.drawers_opened : imagePaths.drawers;
    } 
    // Note Quest Desk (Dossiers)
    else if (this.isDeskDossiersZoomed) { 
      this.currentBackgroundUrl = this.isDeskDossiersOpened ? imagePaths.folders_opened : imagePaths.folders;
    }
    // Paper Quest Desk (Drawers)
    else if (this.isDeskDrawersZoomed) { 
      this.currentBackgroundUrl = this.isDeskDrawersOpened ? imagePaths.drawers_opened : imagePaths.drawers;
    } 

    else if (this.isDoorOpen) { this.currentBackgroundUrl = imagePaths.base_door_open; }
    else { this.currentBackgroundUrl = imagePaths.base; }
  }

  private applyZoom(hotspotKey: string, zoomLevel: number = 1.5): void {
    const hotspotSource = this.hotspots.mainView[hotspotKey as keyof typeof this.hotspots.mainView];
    if (!hotspotSource) return;
    const originX = hotspotSource.x + hotspotSource.width / 2;
    const originY = hotspotSource.y + hotspotSource.height / 2;
    this.zoomStyle = { 'transform': `scale(${zoomLevel})`, 'transform-origin': `${originX}% ${originY}%` };
  }

  private resetZoom(): void {
    this.zoomStyle = { 'transform': 'scale(1)', 'transform-origin': 'center center' };
  }

onCharacterHover(character: string): void {
    const isExploring = this.currentState === GameState.Introduction || 
                        this.currentState === GameState.FindNote || 
                        this.currentState === GameState.NoteFound ||
                        this.currentState === GameState.QuizComplete ||
                        this.currentState === GameState.FindPaper || 
                        this.currentState === GameState.PaperFound || 
                        this.currentState === GameState.AllQuestsComplete;

    if (!isExploring || !this.isMainViewActive || this.activeDialogue) return;

    if (character === 'hrManager') {
      this.currentBackgroundUrl = this.isDoorOpen ? imagePaths.hrHover_door_open : imagePaths.hrHover;
    } else if (character === 'colleague') {
      this.currentBackgroundUrl = this.isDoorOpen ? imagePaths.colleagueHover_door_open : imagePaths.colleagueHover;
    }
  }

  onCharacterLeave(): void {
    if (this.activeDialogue) return;
    this.updateBackground();
  }

onCharacterClick(character: 'hrManager' | 'colleague'): void {
    this.playSound('character-click.mp3');
    this.applyZoom(character);
    let dialogueText = '';
    let dialogueCharacter = ''; 

    if (character === 'colleague') {
      dialogueCharacter = 'Jun (Colleague)'; 
      
      if (this.currentState === GameState.AllQuestsComplete) {
        this.currentBackgroundUrl = imagePaths.colleague_thumbs_up;
        dialogueText = "Great job finishing the training, Alma! You did really well.";
      } 
      else if (this.currentState === GameState.FindPaper) {
        this.currentBackgroundUrl = imagePaths.colleagueTalking;
        if (!this.hasLaptopHint) {
          dialogueText = "The paper? I haven't seen it. Maybe it's under my laptop? You can check."; 
          this.hasLaptopHint = true;
        } else {
          dialogueText = "Just click on the laptop to check."; 
        }
      } 
      else {
        this.currentBackgroundUrl = imagePaths.colleagueTalking;
        dialogueText = "Hey Alma, welcome! I'm Jun. I'm just finishing up a report. Let me know if you need anything."; 
      }
      this.showDialogue({ character: dialogueCharacter, text: dialogueText });
    }

    if (character === 'hrManager') {
      dialogueCharacter = 'Fatma (HR Manager)'; 
      this.currentBackgroundUrl = imagePaths.hrTalking;
      switch (this.currentState) {
        case GameState.Introduction:
          dialogueText = "Hi Alma! I'm Fatma. Before you start working here, there are a few things you should know about our company’s approach to cultural awareness, as many of our colleagues come from different countries around the world.";
          break;
        case GameState.FindNote:
          dialogueText = "Remember to find the sticky note. Start by checking the drawer or the desk."; 
          break;
        case GameState.NoteFound:
          dialogueText = "Well done, you found the sticky note! Therefore, cultural awareness involves recognizing one’s own cultural influences while also understanding the cultural values, beliefs, and practices of others. It goes beyond mere acknowledgment as it requires an active effort to appreciate and engage with different cultures in a respectful and informed manner. Cultural awareness is essential in combating stereotypes, biases, and misunderstandings that often arise from cultural differences. Let’s continue with a quiz. Good luck!"; 
          break;
        case GameState.QuizComplete:
          dialogueText = "I guess you are now more culturally sensitive!"; 
          break;
        case GameState.FindPaper:
          dialogueText = "I don’t remember where I left that paper. Please have a look around the room. Check in the desk behind me, or perhaps near Jun's laptop."; 
          break;
        case GameState.PaperFound:
           dialogueText = "Perfect, you found it! I have a few more quizzes for you, so give it your best shot!"; 
           break;
        case GameState.PuzzleTwo:
        case GameState.PuzzleThree:
           dialogueText = "Please finish the task first.";
           break;
        case GameState.AllQuestsComplete:
           if (!this.hasShownGameCompletePart2) {
             dialogueText = "Well done! You’ve shown how to handle international communication with respect. That’s true cultural awareness.";
           } else {
             dialogueText = "Congratulations, you’ve completed everything and leveled up your cultural awareness. You’re one step closer to thriving in the company. Let’s move on to the next skill.";
           }
           break;
      }
      this.showDialogue({ character: dialogueCharacter, text: dialogueText });
    }
  }

  onHotspotClick(hotspot: string): void {
    this.dismissDialogue();
    this.playSound('click.mp3');

    if (hotspot === 'exitDoor' && this.currentState === GameState.AllQuestsComplete) {
      this.isGameCompleteOverlayVisible = true; 
      return;
    }

    if (this.isMainViewActive) {
      if (hotspot === 'laptop' && this.currentState === GameState.FindPaper) {
        if (this.hasLaptopHint) { 
          this.playSound('paper-rustle.mp3'); 
          this.isPaperVisible = true;
        } else {
          this.showDialogue({ character: 'My Thoughts', text: "I should probably ask Jun before touching his laptop." }); 
        }
        return; 
      }

      this.applyZoom(hotspot, 3.0);
      setTimeout(() => {
        // NOTE QUEST logic
        if (this.currentState === GameState.FindNote) {
          if (hotspot === 'rightBoard') this.isRightBoardZoomed = true;
          else if (hotspot === 'leftBoard') this.isLeftBoardZoomed = true;
          else if (hotspot === 'drawer') this.isDrawersZoomed = true;
          else if (hotspot === 'desk_dossiers') this.isDeskDossiersZoomed = true; 
        } 
        // PAPER QUEST logic
        else if (this.currentState === GameState.FindPaper) {
           if (hotspot === 'desk_drawers') this.isDeskDrawersZoomed = true;
           else if (hotspot === 'leftBoard') this.isLeftBoardZoomed = true;
           else if (hotspot === 'rightBoard') this.isRightBoardZoomed = true;
        }
        
        this.updateBackground();
        this.zoomStyle = {
          'transform': 'scale(1)',
          'transform-origin': 'center center',
          'transition': 'none'
        };
        setTimeout(() => this.resetZoom(), 50);
      }, 1200);
      return;
    }

    // --- REFACTORED Zoomed-in Logic ---
    if (this.currentState === GameState.FindNote) {
      if (hotspot === 'note') {
        this.playSound('paper-rustle.mp3'); 
        this.isNoteVisible = true;
      } else if (hotspot === 'zoomedDrawerClick') {
        this.playSound('drawer-search.wav'); 
        this.isDrawerOpened = true;
        this.updateBackground();
        this.showDialogue({ character: 'My Thoughts', text: "Only some old files inside. It seems what you’re searching for isn’t here. Take a look at the noticeboard on the left." });
      } else if (hotspot === 'zoomedDeskDossiersClick') { 
        this.playSound('folder-search.mp3'); 
        this.isDeskDossiersOpened = true; 
        this.updateBackground();
        this.showDialogue({ character: 'My Thoughts', text: "Just a bunch of dossiers. The note isn't here." });
      } else if (hotspot === 'zoomedLeftBoardMessage') {
        this.showDialogue({ character: 'My Thoughts', text: "This is just a reminder about a meeting. Perhaps you’ll find what you need on the other noticeboard. Give it another try!" });
      }
    } 
    else if (this.currentState === GameState.FindPaper) {
     if (hotspot === 'zoomedDeskDrawersClick') { 
        this.playSound('drawer-search.wav'); 
        this.showDialogue({ character: 'My Thoughts', text: "Nothing here. I should ask Jun." });
      } 
      else {
         this.showDialogue({ character: 'My Thoughts', text: "I already looked here. Fatma said to check the desk or near Jun." });
      }
    }
  }
  
requestHint(): void {
    this.playSound('hint-sound.mp3');
    let hintText = "I'm not sure what to do..."; 

    switch (this.currentState) {
      case GameState.FindNote:
        if (this.isMainViewActive) {
          hintText = "Fatma (the HR Manager) said to 'Start by checking the drawer.' I should click on it.";
        } else if (this.isDrawersZoomed) {
          hintText = "The system message said to 'Take a look at the noticeboard on the left.'";
        } 
        else if (this.isDeskDossiersZoomed) { 
          hintText = "Just dossiers. The note isn't here.";
        }
        else if (this.isLeftBoardZoomed) {
          hintText = "The system message said to 'Give it another try!' on the 'other noticeboard'. That must be the right one.";
        } else if (this.isRightBoardZoomed) {
          hintText = "That sticky note on the board looks important.";
        }
        break;

      case GameState.FindPaper: 
        if (this.isMainViewActive) {
          if (!this.hasLaptopHint) {
            hintText = "Fatma (the HR Manager) said she left the paper in the 'desk' or 'near Jun's laptop'. I should ask Jun before checking his laptop."; 
          } else {
            hintText = "Jun said to check his laptop. I should click on it.";
          }
        } 
        else if (this.isDeskDrawersZoomed) { 
          hintText = "Not in here. I should go back and ask Jun.";
        }
        break;
      
      case GameState.AllQuestsComplete:
        hintText = "I've finished everything. The door is open, I should click on it to leave.";
        break;
    }

    this.showDialogue({ character: 'My Thoughts', text: hintText });
    this.showHints = true;
  }

  startQuest(): void {
    this.currentState = GameState.FindNote;
    this.dismissDialogue();
    this.showDialogue({ character: 'Fatma (HR Manager)', text: "Somewhere in this room, there’s a sticky note with some useful tips. Try to find it and read it carefully, then come back to me. Start by checking the drawer." });
  }

  startQuiz(): void {
    this.dismissDialogue();
    this.quizTitle = 'Cultural awareness quiz- True or False';
    this.quizQuestions = [
      { type: 'tf', text: 'Gestures can sometimes carry different meanings in different cultures.', answer: true, hint: "Think again… In one country, a thumb-up means ‘good job’ (Western countries - USA, UK, Europe), but in another (Middle Eastern countries - Iran, parts of Iraq, Afghanistan), it can be seen as rude. Are gestures always universal?" },
      { type: 'tf', text: 'People coming from the same country share the same culture and communication style.', answer: false, hint: "Think about how people from different regions, age groups, or professions behave, even within one country. Culture isn’t one-size-fits-all!" },
      { type: 'tf', text: 'When someone doesn’t immediately say ‘no,’ it means they agree.', answer: false, hint: "In some cultures, people avoid saying ‘no’ directly to stay polite or maintain harmony. Maybe silence or hesitation means something else?" }
    ];
    this.currentQuizQuestionIndex = 0;
    this.quizFeedback = '';
    this.currentState = GameState.Quiz;
    this.updateBackground();
    this.quizPositionClass = 'left-center';
  }

dismissDialogue(): void {
    if (!this.activeDialogue) return;

    const character = this.activeDialogue.character;
    const state = this.currentState;

    if (character === 'My Thoughts' && this.showHints) {
      setTimeout(() => {
        this.showHints = false;
      }, 3000);
    }

    this.activeDialogue = null;
    this.isTyping = false;
    if (this.dialogueInterval) clearInterval(this.dialogueInterval);

    if (character !== 'My Thoughts') {
      this.resetZoom();
    }

    if (character === 'Fatma (HR Manager)' && state === GameState.QuizComplete) {
       if (!this.hasShownQuizCompletePart2) {
         this.hasShownQuizCompletePart2 = true;
         this.currentState = GameState.FindPaper; // Change state
         this.showDialogue({ 
           character: 'Fatma (HR Manager)', 
           text: "I guess you are now more culturally sensitive! I wrote you in a paper some interesting facts... Check in the desk behind me, or perhaps near Jun's laptop."
         });
         return; // Return to show new dialogue
       }
    } 
    else if (character === 'Fatma (HR Manager)' && state === GameState.PaperFound) {
      if (!this.hasShownPaperFoundPart2) {
        this.hasShownPaperFoundPart2 = true;
        this.currentState = GameState.PuzzleTwo; // Change state
        this.quizPositionClass = 'center-right';
      }
    } 
    else if (character === 'Fatma (HR Manager)' && state === GameState.AllQuestsComplete) {
      if (!this.hasShownGameCompletePart2) {
          this.hasShownGameCompletePart2 = true;
          this.showDialogue({
            character: 'Fatma (HR Manager)',
            text: "Congratulations, you’ve completed everything and leveled up your cultural awareness. You’re one step closer to thriving in the company. Let’s move on to the next skill."
          });
          return; // Return to show new dialogue
      }
      // --- NEW SOUND ADDED HERE ---
      // This runs after the *final* dialogue ("Congratulations...") is dismissed.
      this.playSound('door-open.wav');
    }
    
    this.updateBackground();
  }

  goBack(): void {
    this.playSound('zoom-out.mp3');
    this.resetZoom();
    setTimeout(() => {
      if (!this.isMainViewActive) {
        this.isDrawersZoomed = false;
        this.isDeskDossiersZoomed = false; 
        this.isDeskDrawersZoomed = false;
        this.isRightBoardZoomed = false;
        this.isLeftBoardZoomed = false;
        this.isDrawerOpened = false;
        this.isDeskDossiersOpened = false; 
        this.isDeskDrawersOpened = false;
      }
      this.updateBackground();
    }, 300);
  }

  submitQuiz(answer: boolean): void {
    this.quizFeedback = '';
    this.isQuizWrong = false;
    const currentQuestion = this.currentQuestion;
    if (!currentQuestion) return; 

    if (answer === currentQuestion.answer) {
      this.playSound('success-chime.mp3');
      this.currentQuizQuestionIndex++; 
      if (this.currentQuizQuestionIndex >= this.quizQuestions.length) {
        this.currentState = GameState.QuizComplete;
        this.isQuizCompleteOverlayVisible = true;
      } else {
        this.quizFeedback = '';
      }
    } else {
      this.playSound('error-buzz.mp3');
      this.isQuizWrong = true;
      this.quizFeedback = currentQuestion.hint; 
      setTimeout(() => this.isQuizWrong = false, 820);
    }
  }

  closeQuizCompleteOverlay(): void {
    this.isQuizCompleteOverlayVisible = false;
    this.currentState = GameState.QuizComplete;
    this.showDialogue({ character: 'My Thoughts', text: "I should talk to Fatma (the HR Manager) again." });
  }

  submitPuzzleTwo(answer: 'a' | 'b' | 'c' | 'd'): void {
    this.quizFeedback = '';
    this.isQuizWrong = false;
    if (answer === 'b') {
      this.playSound('success-chime.mp3');
      this.currentState = GameState.PuzzleThree; 
      this.quizPositionClass = 'bottom-left'; 
      this.quizFeedback = '';
    } else {
      this.playSound('error-buzz.mp3');
      this.isQuizWrong = true;
      this.quizFeedback = "Hint: Cultural awareness is about observing and respecting differences, not ignoring or judging them.";
      setTimeout(() => this.isQuizWrong = false, 820);
    }
  }

  addToSequence(optionKey: string): void {
    if (this.puzzleThreeSequence.length < 4 && !this.puzzleThreeSequence.includes(optionKey)) {
      this.puzzleThreeSequence.push(optionKey);
    }
  }

  resetSequence(): void {
    this.puzzleThreeSequence = [];
    this.puzzleThreeFeedback = '';
    this.isQuizWrong = false;
  }

submitSequence(): void {
    const correctSequence = ['c', 'b', 'a', 'd'];
    this.puzzleThreeFeedback = '';
    this.isQuizWrong = false;

    if (JSON.stringify(this.puzzleThreeSequence) === JSON.stringify(correctSequence)) {
      this.playSound('success-chime.mp3');
      
      this.currentState = GameState.AllQuestsComplete;
      this.isDoorOpen = true; 
      
      this.showDialogue({ character: 'Fatma (HR Manager)', text: "Well done! You’ve shown how to handle international communication with respect. That’s true cultural awareness." }); 
    } else {
      this.playSound('error-buzz.mp3');
      this.isQuizWrong = true;
      this.puzzleThreeFeedback = "Think: cultural awareness is about respect and understanding. What should you do first when someone has difficulty being understood?"; 
      setTimeout(() => this.isQuizWrong = false, 820);
    }
  }

  finishGame(): void {
    this.dismissDialogue();
  }

  showDialogue(dialogue: Dialogue): void { this.activeDialogue = dialogue; this.startTypewriter(); }
  
  startTypewriter(): void { 
    if (!this.activeDialogue) return; 
    if (this.dialogueInterval) clearInterval(this.dialogueInterval);
    this.isTyping = true; 
    this.displayedDialogueText = ''; 
    const fullText = this.activeDialogue.text; 
    let i = 0; 
    this.dialogueInterval = setInterval(() => { 
      if (i < fullText.length) { 
        this.displayedDialogueText += fullText.charAt(i); i++; 
      } else { 
        clearInterval(this.dialogueInterval); 
        this.isTyping = false; 
      } 
    }, 30); 
  }
  
  onDialoguePanelClick(): void { if (this.isTyping) { this.skipTyping(); } else { /* Clicks handled by buttons now */ } }
  skipTyping(): void { if (!this.activeDialogue || !this.isTyping) return; clearInterval(this.dialogueInterval); this.displayedDialogueText = this.activeDialogue.text; this.isTyping = false; }
  postponeQuest(): void { this.dismissDialogue(); }
  
  closeNote(): void { 
    this.isNoteVisible = false; 
    if (!this.hasFoundNote) {
      this.hasFoundNote = true; 
      this.currentState = GameState.NoteFound; 
      this.goBack(); 
      this.showDialogue({ character: 'My Thoughts', text: "Good job! Return to the HR Manager." });
    }
  }

  closePaper(): void { 
    this.isPaperVisible = false; 
    if (!this.hasFoundPaper) {
      this.hasFoundPaper = true; 
      this.currentState = GameState.PaperFound;
      this.resetZoom(); 
      this.updateBackground();
      this.showDialogue({ character: 'My Thoughts', text: "I found the paper! I should show this to Fatma (the HR Manager)." }); 
    }
  }

  toggleNote(): void {
    if (this.hasFoundNote) {
      this.playSound('paper-rustle.mp3');
      this.isNoteVisible = !this.isNoteVisible;
      this.isPaperVisible = false;
    }
  }

  togglePaper(): void {
    if (this.hasFoundPaper) {
      this.playSound('paper-rustle.mp3');
      this.isPaperVisible = !this.isPaperVisible;
      this.isNoteVisible = false;
    }
  }

  toggleFullscreen(): void { if (!this.document.fullscreenElement) { this.document.documentElement.requestFullscreen(); } else { this.document.exitFullscreen(); } }
  private onFullscreenChange = (): void => { this.isFullscreen = !!this.document.fullscreenElement; }
}